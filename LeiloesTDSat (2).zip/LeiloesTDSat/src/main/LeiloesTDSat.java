package main;

import view.cadastroVIEW;

public class LeiloesTDSat {

    public static void main(String[] args) {
        
        cadastroVIEW cd = new cadastroVIEW();
        cd.setVisible(true);
        
    }
}
